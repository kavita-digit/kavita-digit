<?php
namespace Meetanshi\CustomerLog\Observer;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\HTTP\PhpEnvironment\RemoteAddress;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Meetanshi\CustomerLog\Model\CustomerConnectionLogFactory;
use Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog as LogResource;

class CustomerLogin implements ObserverInterface
{
    protected $scopeConfig;
    protected $customerSession;
    protected $dateTime;
    protected $remoteAddress;
    protected $customerConnectionLogFactory;
    protected $logResource;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Session $customerSession,
        DateTime $dateTime,
        RemoteAddress $remoteAddress,
        CustomerConnectionLogFactory $customerConnectionLogFactory,
        LogResource $logResource
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->customerSession = $customerSession;
        $this->dateTime = $dateTime;
        $this->remoteAddress = $remoteAddress;
        $this->customerConnectionLogFactory = $customerConnectionLogFactory;
        $this->logResource = $logResource;
    }

    public function execute(Observer $observer)
    {
        $isEnabled = $this->scopeConfig->getValue('customer/customerlog/track_customer_connections', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        
        if ($isEnabled) {
            $customer = $this->customerSession->getCustomer();
            $log = $this->customerConnectionLogFactory->create();
            $log->setData([
                'customer_id' => $customer->getId(),
                'ip' => $this->remoteAddress->getRemoteAddress(),
                'created_at' => $this->dateTime->gmtDate()
            ]);
            $log->save();
        }

        $customer = $observer->getCustomer();
        $customerId = $customer->getId();
        $ip = $_SERVER['REMOTE_ADDR']; // Get customer IP address

        // Create a new log entry
        $log = $this->customerConnectionLogFactory->create();
        $log->setCustomerId($customerId);
        $log->setIp($ip);
        $log->setCreatedAt(date('Y-m-d H:i:s'));
        $log->setUpdatedAt(date('Y-m-d H:i:s'));

        // Save the log entry
        $this->logResource->save($log);

        $customer = $observer->getCustomer();
        $ip = $_SERVER['REMOTE_ADDR'];
        
        $this->logResource->addLog($customer->getId(), $ip);
    }                     
}
