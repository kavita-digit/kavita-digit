<?php
namespace Meetanshi\CustomerLog\Model;

use Magento\Framework\Model\AbstractModel;

class CustomerConnectionLog extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog::class);
    }
}
