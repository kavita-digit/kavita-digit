<?php

namespace Meetanshi\CustomerLog\Model;

use Magento\Framework\Api\Search\AggregationInterface;
use Magento\Framework\Api\Search\ReportingInterface;
use Magento\Framework\Api\Search\SearchResultInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\View\Element\UiComponent\DataProvider\DataProviderInterface;
use Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog\CollectionFactory;

class CustomerLogDataProvider implements DataProviderInterface, ReportingInterface
{
    protected $collectionFactory;
    protected $searchCriteria;

    public function __construct(
        CollectionFactory $collectionFactory,
        SearchCriteriaInterface $searchCriteria
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->searchCriteria = $searchCriteria;
    }

    public function getSearchCriteria()
    {
        return $this->searchCriteria;
    }

    public function setSearchCriteria(SearchCriteriaInterface $searchCriteria)
    {
        $this->searchCriteria = $searchCriteria;
        return $this;
    }

    public function getSearchResult()
    {
        $collection = $this->collectionFactory->create();
        $collection->setCurPage($this->searchCriteria->getCurrentPage());
        $collection->setPageSize($this->searchCriteria->getPageSize());

        return $collection;
    }

    public function getAggregation()
    {
        return null;
    }

    public function getReport()
    {
        return $this->getSearchResult();
    }

    public function getData()
    {
        $collection = $this->getSearchResult();
        return [
            'totalRecords' => $collection->getSize(),
            'items' => $collection->toArray()['items']
        ];
    }
    /**
     * @inheritDoc
     */
    public function addFilter(\Magento\Framework\Api\Filter $filter) {
    }
    
    /**
     * @inheritDoc
     */
    public function addOrder($field, $direction) {
    }
    
    /**
     * @inheritDoc
     */
    public function getConfigData() {
    }
    
    /**
     * @inheritDoc
     */
    public function getFieldMetaInfo($fieldSetName, $fieldName) {
    }
    
    /**
     * @inheritDoc
     */
    public function getFieldSetMetaInfo($fieldSetName) {
    }
    
    /**
     * @inheritDoc
     */
    public function getFieldsMetaInfo($fieldSetName) {
    }
    
    /**
     * @inheritDoc
     */
    public function getMeta() {
    }
    
    /**
     * @inheritDoc
     */
    public function getName() {
    }
    
    /**
     * @inheritDoc
     */
    public function getPrimaryFieldName() {
    }
    
    /**
     * @inheritDoc
     */
    public function getRequestFieldName() {
    }
    
    /**
     * @inheritDoc
     */
    public function setConfigData($config) {
    }
    
    /**
     * @inheritDoc
     */
    public function setLimit($offset, $size) {
    }
    
    /**
     * @inheritDoc
     */
    public function search(\Magento\Framework\Api\Search\SearchCriteriaInterface $searchCriteria) {
    }
}
