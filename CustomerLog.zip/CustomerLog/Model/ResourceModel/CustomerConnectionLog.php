<?php
namespace Meetanshi\CustomerLog\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class CustomerConnectionLog extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('customer_connections_logs', 'log_id');
    }
}
