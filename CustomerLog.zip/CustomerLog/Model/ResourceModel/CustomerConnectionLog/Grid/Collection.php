<?php
namespace Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog\Grid;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;
use Meetanshi\CustomerLog\Model\CustomerConnectionLog as CustomerConnectionLogResource;

class Collection extends SearchResult
{
   
    protected function _construct()
    {
        $this->_init('Meetanshi\CustomerLog\Model\CustomerConnectionLog', CustomerConnectionLogResource::class);
    }
    
}
