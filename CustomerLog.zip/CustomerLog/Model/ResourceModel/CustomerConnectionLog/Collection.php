<?php
namespace Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Meetanshi\CustomerLog\Model\CustomerConnectionLog as Model;
use Meetanshi\CustomerLog\Model\ResourceModel\CustomerConnectionLog as ResourceModel;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'customerlog_grid_collection';
    protected $_eventObject = 'customerlog_collection';
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
